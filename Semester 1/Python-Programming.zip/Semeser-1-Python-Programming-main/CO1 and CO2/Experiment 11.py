#Experiment 11:
#A program to check whether a number is odd or even:
#Declaring a variable to which the user inputs the required number:
Nmb=int(input("Enter any number : "))
#Using if function to check whether the remainder of the number is zero when divided by 2:
if(Nmb%2==0):
    print("The number",Nmb,"is an even number")
else:
    print("The number",Nmb,"is a odd number")
