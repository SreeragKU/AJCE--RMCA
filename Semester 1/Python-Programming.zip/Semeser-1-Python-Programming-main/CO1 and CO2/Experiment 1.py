#Experiment 1:
#A program to find the area of a rectangle:
#Declaring a variable to which the user inputs the length of the rectangle:
Lth=int(input("Enter the length of the rectangle : "))

#Declaring another variable to which the user inputs the breadth of the rectangle:
Bth=int(input("Enter the breadth of the rectangle : "))

#Calculation:
AR=Lth*Bth      #Area of a rectangle= Length * Breadth

#Printing the result:
print("The area of the rectangle = ",AR)
