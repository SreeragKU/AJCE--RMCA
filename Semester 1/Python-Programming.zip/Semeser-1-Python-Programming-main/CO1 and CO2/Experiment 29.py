#Experiment 29:
#A program to find the greatest common divisor (GCD) of two numbers:
import math
#Declaring two variable to which the user inputs the two numbers:
Nmb1=int(input("Enter any positive number : "))
Nmb2=int(input("Enter any positive number : "))
gcd=math.gcd(Nmb1,Nmb2)
print("The Greatest Common Divisor of",Nmb1,"and",Nmb2,"is",gcd)
