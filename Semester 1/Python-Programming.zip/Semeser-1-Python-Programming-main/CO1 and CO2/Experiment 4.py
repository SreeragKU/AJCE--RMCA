#Experiment 4:
#A program to convert Kilometers into Miles:

#Declaring a variable to which the user inputs the distance in Kilometers:
Klmtr=int(input("Enter the distance in Kilometers : "))

#Calculation:
Mls= 0.621371*Klmtr     # 1 Kilometer = 0.621 Miles

#Printing the result:
print("The distance,",Klmtr,"Km = ",Mls," Miles")