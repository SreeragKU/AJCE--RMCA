def staff ( ):
    print("Hello staff")
def student ( ):
    print("Hi students")
