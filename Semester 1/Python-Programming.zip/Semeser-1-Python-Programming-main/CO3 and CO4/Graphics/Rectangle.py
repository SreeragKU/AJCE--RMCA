def area(x, y):
    print("Area of rectangle: ", x * y)

def Perimeter(x, y):
    print("Perimeter of rectangle: ", 2 * (x + y))
