def area(r):
    print("Area of Circle: ", 3.14 * r * r)

def Perimeter(r):
    print("Perimeter of Circle: ", 2 * 3.14 * r)
