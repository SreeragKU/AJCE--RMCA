def area(x, y, z):
    print("Area of cuboid: ", 2 * (x * y + y * z + x * z))

def Perimeter(x, y, z):
    print("Perimeter of cuboid: ", 4 * (x + y + z))
