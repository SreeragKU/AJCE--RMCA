def area(r):
    print("Volume of sphere: ", 4 / 3 * 3.14 * r * r * r)


def Perimeter(r):
    print("Surface area of a sphere: ", 4 * 3.14 * r * r * r)
