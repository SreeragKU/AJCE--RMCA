import Engg. Years. Sem as m
m.staff ( )
m.student ( )
