from datetime import date, timedelta
dt=date.today()+timedelta(5)
print("Current Date:",date.today())
print("5 Days after Current Date:",dt)
