<?php
$Str=mysqli_connect("localhost","root","","book");
?>
