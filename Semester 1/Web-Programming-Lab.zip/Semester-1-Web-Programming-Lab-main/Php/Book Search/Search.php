<html>
    <body>
    <center><h2>FIND YOUR BOOK</h2></center>
    <form action = "displaybook.php" method="GET">
        <center>Enter the title of the book to be searched :
        <input type="text" name="search" size="48">
        <br></br>
        <input type="submit" value="Search">
        <input type="reset" value="Reset">
        </center>
        <br>
        </form>
    </body>
</html>
