package Graphics; 
interface Area{
	public void Rectangle(); 
	public void Triangle(); 
	public void Square(); 
	public void Circle(); 
}