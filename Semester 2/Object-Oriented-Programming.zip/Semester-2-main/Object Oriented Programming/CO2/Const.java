public class Const{
	int num;
	public Const(){
		num = 150;
	}
	public static void main(String[] args){
		Const ob1 = new Const();
		System.out.println(ob1.num);
	}
}